import asyncio
from aiohttp import web

from inventory_api.database import get_db, close_db
from inventory_api.config import config
from inventory_api.redis_pub import get_redis, close_redis
from inventory_api.run_handlers import setup_handlers

from shared.logger import get_logger

logger = get_logger(__name__)


async def close_all(app: web.Application) -> None:
    await close_db()
    await close_redis()
    
    await app.shutdown()
    await app.cleanup()
    
    logger.info("Все остановлено")


async def main() -> None:
    await get_db()
    logger.info("База данных инициализирована")

    await get_redis()
    logger.info("Redis запущен")

    app = web.Application()
    app.on_shutdown.append(close_all)
    await setup_handlers(app)

    runner = web.AppRunner(app)
    await runner.setup()

    site = web.TCPSite(runner, config.host, config.port)
    await site.start()
    logger.info(f"API запущен на {config.host}:{config.port}")

    await asyncio.Event().wait() 


if __name__ == '__main__':
    asyncio.run(main())
