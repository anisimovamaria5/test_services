from aiohttp import web
from inventory_api.handlers import Handlers

async def setup_handlers(app: web.Application):
    """Настройка маршрутов для приложения"""
    
    handler = Handlers()
    app.router.add_post('/receipts', handler.post_receipts, name='post_receipts')
    app.router.add_post('/issues', handler.post_issues, name='post_issues')
    app.router.add_get('/stock', handler.get_stock, name='get_stock')
    app.router.add_get('/stock/summary', handler.get_stock_summary, name='get_stock_summary')
