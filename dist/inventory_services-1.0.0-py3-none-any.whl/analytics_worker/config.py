import os
from dataclasses import dataclass
from dotenv import load_dotenv

load_dotenv() 

@dataclass(frozen=True)
class Config:
    database_url: str
    redis_url: str
    host: str = "0.0.0.0"
    port: int = 8080


config = Config(
    database_url=os.getenv('DATABASE_URL', 'postgresql+asyncpg://postgres:postgres@localhost:5432/inventory'),
    redis_url=os.getenv('REDIS_URL', 'redis://localhost:6379'),
    host=os.getenv('API_HOST', '0.0.0.0'),
    port=int(os.getenv('API_PORT', '8080'))
)


class Channels:
    """Названия каналов Redis"""

    RECEIPT = 'inventory.receipt'
    ISSUE = 'inventory.issue'