import asyncio
import json
from typing import Any, Dict
import aioredis
from sqlalchemy import insert, select, update

from analytics_worker.config import config, Channels
from analytics_worker.database import async_engine
from analytics_worker.models import stock_agg
from shared.logger import get_logger

logger = get_logger(__name__)

_redis = None
subscriber = None


async def get_redis() -> None:
    """Инициализация Redis"""

    global _redis, subscriber
    try:
        _redis = await aioredis.from_url(
            config.redis_url,
            decode_responses=True, 
            max_connections=10
        )
        subscriber = _redis.pubsub()
        logger.info("Redis инициализирован")
    except Exception as e:
        logger.error(f"Ошибка в инициализации Redis: {e}")
        raise
    

async def close_redis() -> None:
    """Закрытие Redis"""

    global _redis, subscriber
    if subscriber:
        await subscriber.unsubscribe()
        await subscriber.close()
        subscriber = None
    if _redis:
        await _redis.close()
        _redis = None
        logger.info("Redis закрыт")


async def handle_event(message: Dict[str, Any]) -> None:
    """Обработка полученного события"""

    data = json.loads(message['data'])
    event_type = data.get('type')
    sku = data.get('sku')
    qty = data.get('qty')
    warehouse = data.get('warehouse')

    if event_type == Channels.RECEIPT:
        delta = qty
    elif event_type == Channels.ISSUE:
        delta = -qty
    else:
        logger.warning(f"Неизвестный тип события: {event_type}")
        return

    async with async_engine.begin() as conn:
        stmt = select(stock_agg).where(
            stock_agg.c.sku == sku,
            stock_agg.c.warehouse == warehouse
        ) 
        res = await conn.execute(stmt)
        row = res.fetchone()

        if row:
           new_qty =row.total_qty + delta
           await conn.execute(
               update(stock_agg).where(
                   stock_agg.c.sku == sku, 
                   stock_agg.c.warehouse == warehouse
               ).values(total_qty=new_qty)
           )
        else:
            await conn.execute(
                insert(stock_agg).values(
                    sku=sku, 
                    warehouse=warehouse, 
                    total_qty=delta
                )
            )


async def run_worker() -> None:
    """Запуск worker"""

    await get_redis()

    await subscriber.subscribe(Channels.RECEIPT)
    await subscriber.subscribe(Channels.ISSUE)
    logger.info(f"Подписан на каналы: {Channels.RECEIPT}, {Channels.ISSUE}")
    
    try:
        async for message in subscriber.listen():
            if message['type'] == 'message':
                await handle_event(message)
            elif message['type'] == 'subscribe':
                logger.info(f"Подписан на канал: {message['channel']}")
    except asyncio.CancelledError:
        logger.info("Worker остановлен")
    finally:
        await close_redis()
