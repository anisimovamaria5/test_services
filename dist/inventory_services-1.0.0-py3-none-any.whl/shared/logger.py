import logging
import sys


def get_logger(name: str = "inventory") -> logging.Logger:
    """
    Единый логгер для всего приложения
    
    Args:
        name: Имя логгера
        
    Returns:
        logging.Logger: Логгер
    """
    logger = logging.getLogger(name)
    
    if not logger.handlers:
        logger.setLevel(logging.INFO)
        
        handler = logging.StreamHandler(sys.stdout)
        formatter = logging.Formatter(
            '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
        )
        handler.setFormatter(formatter)
        logger.addHandler(handler)
        
        logger.propagate = False
    
    return logger